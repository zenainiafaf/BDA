import oracledb from "oracledb";

// Activer mode Thick avec le chemin vers Instant Client
oracledb.initOracleClient({ libDir: "C:\\oracle\\instantclient_11_2" });

async function testConnexion() {
  try {
    const connection = await oracledb.getConnection({
      user: "SQL3",
      password: "sql3_password",
      connectString: "localhost:1521/XE",
    });

    console.log("✅ Connexion Oracle réussie !");
    const result = await connection.execute(`SELECT 'OK' AS TEST FROM dual`);
    console.log("Résultat de test :", result.rows);

    await connection.close();
    console.log("🔒 Connexion Oracle fermée.");
  } catch (err) {
    console.error("❌ ERREUR de connexion Oracle :", err);
  }
}

testConnexion();
