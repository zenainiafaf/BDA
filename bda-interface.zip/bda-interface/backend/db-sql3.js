import oracledb from "oracledb";

// Activer mode Thick avec le chemin vers Instant Client
oracledb.initOracleClient({ libDir: "C:\\oracle\\instantclient_11_2" });

export const getOracleConnection = async () => {
  try {
    // Établir la connexion à la base de données Oracle
    const conn= await oracledb.getConnection({
      user: "SQL3",               // Remplacer par ton utilisateur Oracle
      password: "sql3_password",   // Remplacer par ton mot de passe
      connectString: "localhost:1521/XE",  // Remplacer par ton connectString
    });
    

    console.log("✅ Connexion Oracle réussie !");
    
    // Tester la connexion avec une requête simple
    const result = await conn.execute(`SELECT 'OK' AS TEST FROM dual`);
    console.log("Résultat de test :", result.rows);

    return conn;
 
  } catch (err) {
    console.error("❌ ERREUR de connexion Oracle :", err);
    throw err;
  }
};

// Appeler la fonction pour tester la connexion
getOracleConnection();
