import { MongoClient } from "mongodb";

const uri = "mongodb://127.0.0.1:27017";
const client = new MongoClient(uri);
let db = null;

async function getMongoDB() {
  if (db) return db;

  try {
    await client.connect();
    console.log("✅ Connexion MongoDB établie !");
    db = client.db("smartcity");
    return db;
  } catch (err) {
    console.error("❌ Erreur de connexion MongoDB :", err);
    throw err;
  }
}

export default getMongoDB;
