import express from 'express';
import cors from 'cors';
import oracledb from 'oracledb';
import { MongoClient } from 'mongodb';
import { getOracleConnection } from './db-sql3.js';

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Oracle Client
oracledb.initOracleClient({ libDir: "C:\\oracle\\instantclient_11_2" });

// Route test
app.get('/', (req, res) => {
  res.send("Bienvenue sur le serveur !");
});

// Route SQL3
app.post('/sql3', async (req, res) => {
  try {
    const { requete } = req.body;
    if (!requete) return res.status(400).json({ error: 'Aucune requête reçue.' });
    
    const conn = await getOracleConnection();
    const result = await conn.execute(requete);
    await conn.close();
    
    res.json(result.rows);
  } catch (err) {
    console.error("❌ Erreur SQL :", err);
    res.status(500).json({ error: 'Erreur lors de exécution de la requête SQL' });
  }
});

const mongoUrl = "mongodb://127.0.0.1:27017";
const dbName = "smartcity";
let mongoDb;

// Connexion MongoDB
MongoClient.connect(mongoUrl)
  .then(client => {
    console.log("✅ Connexion MongoDB réussie !");
    mongoDb = client.db(dbName);
  })
  .catch(err => {
    console.error("❌ Erreur MongoDB :", err);
  });

// Route MongoDB
app.post('/mongodb', async (req, res) => {
  const { requete, type, targetCollection } = req.body;
  
  if (!requete) {
    return res.status(400).json({ error: 'Aucune requête reçue' });
  }
  
  try {
    // Vérifier que la connexion MongoDB existe
    if (!mongoDb) {
      throw new Error('Connexion MongoDB non établie');
    }

    // Nettoyage de la requête
    let cleanedRequete = requete
      .replace(/ISODate\(/g, 'new Date(')
      .replace(/\.pretty\(\)/g, '')
      .trim();
    
    // Déterminer la collection cible
    let collectionName = 'voyages';
    if (targetCollection) {
      collectionName = targetCollection;
    } else {
      const collectionMatch = cleanedRequete.match(/db\.(\w+)\./);
      if (collectionMatch && collectionMatch[1]) {
        collectionName = collectionMatch[1];
      }
    }
    
    // Vérifier que la collection existe ou la créer si nécessaire
    const collections = await mongoDb.listCollections({name: collectionName}).toArray();
    if (collections.length === 0 && ['bonVoyage', 'ligneVoyages', 'ligneVoyagesMapReduce'].includes(collectionName)) {
      console.log(`Collection ${collectionName} non trouvée, elle sera créée si nécessaire par l'opération`);
    }
    
    // Exécution selon le type
    let result;
    switch(type) {
      case 'find':
        // Pour les collections comme bonVoyage, ligneVoyages, etc.
        if (['bonVoyage', 'ligneVoyages', 'ligneVoyagesMapReduce'].includes(collectionName)) {
          // Si la requête inclut sort et limit pour ligneVoyagesMapReduce, on l'applique
          if (collectionName === 'ligneVoyagesMapReduce' && cleanedRequete.includes('.sort(') && cleanedRequete.includes('.limit(')) {
            result = await mongoDb.collection(collectionName).find({}).sort({ value: -1 }).limit(5).toArray();
          } else {
            result = await mongoDb.collection(collectionName).find({}).toArray();
          }
        } else {
          // Extraction des critères de recherche pour les collections standards
          const queryText = cleanedRequete.replace(`db.${collectionName}.find(`, '').replace(/\)\s*$/, '');
          // S'il y a des critères, on les évalue
          const query = queryText ? eval(`(${queryText})`) : {};
          result = await mongoDb.collection(collectionName).find(query).toArray();
        }
        break;
        
      case 'aggregate':
        const pipelinePart = cleanedRequete.replace(`db.${collectionName}.aggregate(`, '').replace(/\)\s*$/, '');
        const pipeline = eval(`(${pipelinePart})`);
        result = await mongoDb.collection(collectionName).aggregate(pipeline).toArray();
        break;
        
      case 'updateMany':
        const parts = cleanedRequete.replace(`db.${collectionName}.updateMany(`, '').replace(/\)\s*$/, '').split(/,(?=\s*\{)/);
        const filter = eval(`(${parts[0]})`);
        const update = eval(`(${parts[1]})`);
        const updateResult = await mongoDb.collection(collectionName).updateMany(filter, update);
        result = {
          matchedCount: updateResult.matchedCount,
          modifiedCount: updateResult.modifiedCount,
          message: `Documents modifiés: ${updateResult.modifiedCount}`
        };
        break;
        
      default:
        throw new Error(`Type de requête non supporté: ${type}`);
    }
    
    res.json(result);
  } catch (err) {
    console.error("❌ Erreur MongoDB:", err);
    res.status(500).json({
      error: err.message,
      stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
    });
  }
});

// Gestion des erreurs 404
app.use((req, res) => {
  res.status(404).json({ error: "Endpoint non trouvé" });
});

// Lancement serveur
app.listen(3000, () => {
  console.log("✅ Serveur en écoute sur http://localhost:3000");
});