import React, { useState } from 'react';
import QuestionCard from './QuestionCard';
import './Home.css';
import dzImage from "../assets/dz.jpg";

const questions = [
  {
    id: 1,
    title: "Voyages par date",
    description: "Afficher les voyages du 01/01/2025",
    displayRequete: `db.voyages.find({ 
  dateVoyage: { 
    $gte: ISODate("2025-01-01T00:00:00Z"), 
    $lt: ISODate("2025-01-02T00:00:00Z") 
  } 
}).pretty()`,
    execRequete: `db.voyages.find({ 
  dateVoyage: { 
    $gte: new Date("2025-01-01T00:00:00Z"), 
    $lt: new Date("2025-01-02T00:00:00Z") 
  } 
})`,
    type: 'find'
  },
  {
    id: 2,
    title: "Voyages sans problème",
    description: "Voyages avec observation RAS",
    displayRequete: `
db.voyages.aggregate([
  { $match: { observation: "RAS" } },
  { $project: { 
    numeroV: 1,
    numLigne: "$navette.ligne.codeL",
    dateVoyage: 1,
    heureDebut: 1,
    sens: 1,
    moyenTransport: "$navette.ligne.moyenTransport.abreviation",
    numeroNavette: "$navette.numeroN",
    _id: 0
  }},
  { $out: "bonVoyage" }
]);

// Afficher les résultats
db.bonVoyage.find().pretty()`,
    execRequete: `db.bonVoyage.find()`,
    type: 'find',
    targetCollection: 'bonVoyage'
  },
  {
    id: 3,
    title: "Voyages par ligne",
    description: "Nombre de voyages par ligne de transport",
    displayRequete: `
db.voyages.aggregate([
  { $group: { 
    _id: "$navette.ligne.codeL", 
    totalVoyages: { $sum: 1 }
  }},
  { $project: {
    numeroLigne: "$_id",
    totalVoyages: 1,
    _id: 0
  }},
  { $sort: { totalVoyages: -1 } },
  { $out: "ligneVoyages" }
]);

// Afficher les résultats
db.ligneVoyages.find().pretty()`,
    execRequete: `db.ligneVoyages.find()`,
    type: 'find',
    targetCollection: 'ligneVoyages'
  },
  {
    id: 4,
    title: "Augmentation voyageurs MET",
    description: "+100 voyageurs pour les métros avant le 15/01/2025",
    displayRequete: `db.voyages.updateMany(
  { 
    "navette.ligne.moyenTransport.abreviation": "MET",
    "dateVoyage": { $lt: ISODate("2025-01-15T00:00:00Z") }
  },
  { 
    $inc: { "nombreVoyageurs": 100 }
  }
)`,
    execRequete: `db.voyages.updateMany(
  { 
    "navette.ligne.moyenTransport.abreviation": "MET",
    "dateVoyage": { $lt: new Date("2025-01-15T00:00:00Z") }
  },
  { 
    $inc: { "nombreVoyageurs": 100 }
  }
)`,
    type: 'updateMany'
  },
  {
    id: 5,
    title: "MapReduce par ligne",
    description: "Compter les voyages par ligne avec MapReduce",
    displayRequete: `
var mapFunction = function() {
  emit(this.navette.ligne.codeL, 1);
};

var reduceFunction = function(codeLigne, compteurs) {
  return Array.sum(compteurs);
};

db.voyages.mapReduce(
  mapFunction,
  reduceFunction,
  {
    out: "ligneVoyagesMapReduce",
    verbose: true
  }
);

//Afficher les résultats
db.ligneVoyagesMapReduce.find().sort({ value: -1 });`,
    execRequete: `db.ligneVoyagesMapReduce.find().sort({ value: -1 })`,
    type: 'find',
    targetCollection: 'ligneVoyagesMapReduce'
  },
  {
    id: 6,
    title: "Navettes les plus utilisées",
    description: "Navettes avec le plus grand nombre de voyages",
    displayRequete: `db.voyages.aggregate([
  { $group: {
    _id: {
      navette: "$navette.numeroN", 
      moyenTransport: "$navette.ligne.moyenTransport.abreviation"
    },
    totalVoyages: { $sum: 1 }
  }},
  { $sort: { totalVoyages: -1 } },
  { $group: {
    _id: null,
    maxVoyages: { $first: "$totalVoyages" },
    navettes: {
      $push: {
        navette: "$_id.navette",
        moyenTransport: "$_id.moyenTransport",
        totalVoyages: "$totalVoyages"
      }
    }
  }},
  { $project: {
    navettes: {
      $filter: {
        input: "$navettes",
        as: "n",
        cond: { $eq: ["$$n.totalVoyages", "$maxVoyages"] }
      }
    }
  }},
  { $unwind: "$navettes" },
  { $replaceRoot: { newRoot: "$navettes" }}
])`,
    execRequete: `db.voyages.aggregate([
  { $group: {
    _id: {
      navette: "$navette.numeroN", 
      moyenTransport: "$navette.ligne.moyenTransport.abreviation"
    },
    totalVoyages: { $sum: 1 }
  }},
  { $sort: { totalVoyages: -1 } },
  { $group: {
    _id: null,
    maxVoyages: { $first: "$totalVoyages" },
    navettes: {
      $push: {
        navette: "$_id.navette",
        moyenTransport: "$_id.moyenTransport",
        totalVoyages: "$totalVoyages"
      }
    }
  }},
  { $project: {
    navettes: {
      $filter: {
        input: "$navettes",
        as: "n",
        cond: { $eq: ["$$n.totalVoyages", "$maxVoyages"] }
      }
    }
  }},
  { $unwind: "$navettes" },
  { $replaceRoot: { newRoot: "$navettes" }}
])`,
    type: 'aggregate'
  },
  {
    id: 7,
    title: "Dépassement seuil voyageurs",
    description: "Moyens de transport dépassant 1000 voyageurs/jour",
    displayRequete: `db.voyages.aggregate([
  { $group: {
    _id: {
      date: { $dateToString: { format: "%Y-%m-%d", date: "$dateVoyage" } },
      moyenId: "$navette.ligne.moyenTransport._id",
      moyenAbrev: "$navette.ligne.moyenTransport.abreviation"
    },
    totalVoyageurs: { $sum: "$nombreVoyageurs" }
  }},
  { $match: { totalVoyageurs: { $gt: 1000 } } },
  { $sort: { "_id.date": 1 } },
  { $project: {
    _id: 0,
    date: "$_id.date",
    moyenId: "$_id.moyenId",
    moyen: "$_id.moyenAbrev",
    totalVoyageurs: 1
  }}
])`,
    execRequete: `db.voyages.aggregate([
  { $group: {
    _id: {
      date: { $dateToString: { format: "%Y-%m-%d", date: "$dateVoyage" } },
      moyenId: "$navette.ligne.moyenTransport._id",
      moyenAbrev: "$navette.ligne.moyenTransport.abreviation"
    },
    totalVoyageurs: { $sum: "$nombreVoyageurs" }
  }},
  { $match: { totalVoyageurs: { $gt: 1000 } } },
  { $sort: { "_id.date": 1 } },
  { $project: {
    _id: 0,
    date: "$_id.date",
    moyenId: "$_id.moyenId",
    moyen: "$_id.moyenAbrev",
    totalVoyageurs: 1
  }}
])`,
    type: 'aggregate'
  }
];

const MongoDBPage = () => {
  const [selected, setSelected] = useState(null);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const executeRequete = async () => {
    if (!selected) return;
    
    setError(null);
    setIsLoading(true);
    
    try {
      const response = await fetch('http://localhost:3000/mongodb', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          requete: selected.execRequete,
          type: selected.type,
          targetCollection: selected.targetCollection
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Erreur HTTP: ${response.status}`);
      }

      const data = await response.json();
      setResult(data);
    } catch (err) {
      console.error("Erreur lors de l'exécution:", err);
      setError(err.message);
      setResult(null);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="page-container">
      {!selected && (
        <div className="cards-container">
          {questions.map((q, i) => (
            <QuestionCard 
              key={i} 
              question={q} 
              onSelect={() => setSelected(q)} 
            />
          ))}
        </div>
      )}
  
      {selected && (
        <div className="selected-container">
          <div className="left-half">
            <img src={dzImage} alt="MongoDB Illustration" />
          </div>
  
          <div className="right-half">
            <h2>{selected.title}</h2>
            <p>{selected.description}</p>
  
            <h4>Requête MongoDB :</h4>
            <pre className="requete-box">{selected.displayRequete}</pre>
  
            <div className="button-group">
              <button 
                className="action-button" 
                onClick={executeRequete}
                disabled={isLoading}
              >
                {isLoading ? 'Exécution...' : 'Exécuter la requête'}
              </button>
              <button 
                className="action-button secondary"
                onClick={() => {
                  setSelected(null);
                  setResult(null);
                  setError(null);
                }}
              >
                Retour
              </button>
            </div>
  
            {error && (
              <div className="error-message">
                <h4>Erreur :</h4>
                <pre>{error}</pre>
              </div>
            )}
  
            {result && (
              <div className="result-container">
                <h4>Résultats :</h4>
                <pre>{JSON.stringify(result, null, 2)}</pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default MongoDBPage;