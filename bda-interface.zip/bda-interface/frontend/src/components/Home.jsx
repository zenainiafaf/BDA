import './Home.css'; 
import usthbLogo from '../assets/logo.png'; 

export default function Home() {
  return (
    <div className="home-container">
      <div className="overlay">
        <div className="content">
          <h1>Projet BDA : Smart City</h1>
          <h2>Gestion d’un réseau de transport intelligent</h2>
          <p>
            <strong>Enseignantes :</strong> Mme. Boukhedouma Saida   & Mme. Challal Zakia<br />
            <strong>Réalisé par :</strong> Mezioug Liza & Zenaini Afaf Farah
          </p>
        </div>
        <footer className="footer">
        <img src={usthbLogo} alt="USTHB" className="footer-logo" />
        
        <div className="footer-content">
          <p className="footer-line">Université des Sciences et de la Technologie Houari Boumediene</p>
          <p className="footer-line">Faculté d'Informatique </p>
          <p className="footer-line">Département Intelligence Artificielle et Science des Données (IA & SD) </p>
          <p className="footer-line">Master 1 Systèmes Informatiques Intelligents</p>
        </div>
        
        <img src={usthbLogo} alt="USTHB" className="footer-logo" />
      </footer>
      </div>
    </div>
  );
}
